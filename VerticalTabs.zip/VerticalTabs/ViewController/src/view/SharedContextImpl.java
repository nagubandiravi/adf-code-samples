package view;

import java.util.HashMap;

public class SharedContextImpl extends HashMap{
    
    final String RETURN_VALUE = "___returnValue_____";
    
    public SharedContextImpl() {
        super();
        this.put(RETURN_VALUE, null);
    }
    
    public void setReturnValue(Object returnValue) {
        this.put(RETURN_VALUE, returnValue);
    }

    public Object getReturnValue() {
        return this.get(RETURN_VALUE);
    }

}
