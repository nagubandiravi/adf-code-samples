package view;

import entity.EndPoint;


public class EndPointViewBean {
    
    private EndPoint endPoint = null;
    
    public EndPointViewBean() {
        super();
    }
    
    public void init() {
        TabBean parentBean = (TabBean) ADFUtil.evaluateEL("#{pageFlowScope.bean}");
        if (null != parentBean) {
            this.setEndPoint(endPoint);
        }
    }
    
    public void setEndPoint(EndPoint endPoint) {
        this.endPoint = endPoint;
    }

    public EndPoint getEndPoint() {
        return endPoint;
    }
    
    public void finalizeTF() {
//        UIComponent comp = (UIComponent) ADFUtil.evaluateEL("#{backingBeanScope.pfBinding}");
//        if (null != comp) {
//            comp.getChildren().clear();
//            AdfFacesContext.getCurrentInstance().addPartialTarget(comp);
//        }
    }
}
