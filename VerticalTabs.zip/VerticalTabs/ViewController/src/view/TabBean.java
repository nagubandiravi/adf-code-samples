package view;

import entity.EndPoint;
import entity.NetworkService;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Stack;

import javax.faces.component.UIComponent;
import javax.faces.event.ActionEvent;

import oracle.adf.controller.TaskFlowId;
import oracle.adf.controller.binding.TaskFlowBindingAttributes;
import oracle.adf.view.rich.component.rich.layout.RichPanelBox;
import oracle.adf.view.rich.context.AdfFacesContext;

public class TabBean {
    
    private int counter = 0;
    
    private NetworkService networkService = null;
    
    private List<TaskFlowBindingAttributes> taskFlowBindings = new ArrayList<TaskFlowBindingAttributes>();
    
    private LinkedHashMap<String, Object> parameterMap = new LinkedHashMap<String, Object>();
    
    private List<String> epNames = new ArrayList<String>();
    
    private Stack<TaskFlowBindingAttributes> regionStack = new Stack<TaskFlowBindingAttributes>();
    
    private LinkedHashMap<Integer, EndPoint> epMap = new LinkedHashMap<Integer, EndPoint>();
    
    private LinkedHashMap<String, LinkedHashMap<String, Object>> taskFlowInstanceParameters = new LinkedHashMap<String, LinkedHashMap<String, Object>>();

    public TabBean() {
        networkService = new NetworkService();
    }

    public void addEndPointRegion(ActionEvent actionEvent) {
//        taskFlowBindings = new ArrayList<TaskFlowBindingAttributes>();
        int count = (this.epMap.keySet().size()+1);
        
        for (int i=1; i<=count; i++) {
            if (!(taskFlowInstanceParameters.containsKey(String.valueOf(i)))) {
                TaskFlowBindingAttributes tfAttr = new TaskFlowBindingAttributes();
                EndPoint endPoint = new EndPoint();
                tfAttr.setId("EndPoint"+i);
                tfAttr.setTaskFlowId(new TaskFlowId("/WEB-INF/EndPointFlow.xml", "EndPointFlow"));
                LinkedHashMap<String, Object> parameterMap = new LinkedHashMap<String, Object>();
                parameterMap.put("bean", this);
                parameterMap.put("endPoint", endPoint);
                taskFlowInstanceParameters.put(String.valueOf(i), parameterMap); 
                if (!(epMap.containsKey(i))) {
                    epMap.put(i, endPoint);
                }
                tfAttr.setParametersMap("#{pageFlowScope.TabBean.taskFlowInstanceParameters['" + i + "']}");
                taskFlowBindings.add(tfAttr);
            }
        }
                
        UIComponent comp = (UIComponent) ADFUtil.evaluateEL("#{backingBeanScope.epBinding}");
        AdfFacesContext.getCurrentInstance().addPartialTarget(comp);
    }

    public void deleteEndPointRegion(ActionEvent actionEvent) {
        UIComponent comp = (UIComponent) actionEvent.getSource();
        while (null != comp) {
            if (!(comp instanceof RichPanelBox)) {
                comp = comp.getParent();
                continue;
            } else {
                break;
            }
        }
        RichPanelBox rpb = (RichPanelBox) comp;
        rpb.setRendered(false);
        
        UIComponent pbBinding = (UIComponent) ADFUtil.evaluateEL("#{backingBeanScope.epBinding}");
        AdfFacesContext.getCurrentInstance().addPartialTarget(pbBinding);

    }

    public void setTaskFlowBindings(List<TaskFlowBindingAttributes> taskFlowBindings) {
        this.taskFlowBindings = taskFlowBindings;
    }

    public List<TaskFlowBindingAttributes> getTaskFlowBindings() {
        return taskFlowBindings;
    }

    public void setNetworkService(NetworkService networkService) {
        this.networkService = networkService;
    }

    public NetworkService getNetworkService() {
        return networkService;
    }

    public void save(ActionEvent actionEvent) {
        
    }

    public void setParameterMap(LinkedHashMap<String, Object> parameterMap) {
        this.parameterMap = parameterMap;
    }

    public LinkedHashMap<String, Object> getParameterMap() {
        return parameterMap;
    }

    public void setEpNames(List<String> epNames) {
        this.epNames = epNames;
    }

    public List<String> getEpNames() {
        return epNames;
    }

    public void setCounter(int counter) {
        this.counter = counter;
    }

    public int getCounter() {
        return counter;
    }

    public void setRegionStack(Stack<TaskFlowBindingAttributes> regionStack) {
        this.regionStack = regionStack;
    }

    public Stack<TaskFlowBindingAttributes> getRegionStack() {
        return regionStack;
    }

    public void setEpMap(LinkedHashMap<Integer, EndPoint> epMap) {
        this.epMap = epMap;
    }

    public LinkedHashMap<Integer, EndPoint> getEpMap() {
        return epMap;
    }

    public void setTaskFlowInstanceParameters(LinkedHashMap<String, LinkedHashMap<String, Object>> taskFlowInstanceParameters) {
        this.taskFlowInstanceParameters = taskFlowInstanceParameters;
    }

    public LinkedHashMap<String, LinkedHashMap<String, Object>> getTaskFlowInstanceParameters() {
        return taskFlowInstanceParameters;
    }
}
