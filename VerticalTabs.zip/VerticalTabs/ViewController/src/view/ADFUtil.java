/* Copyright (c) 2008, 2012, Oracle and/or its affiliates. 
All rights reserved. */
package view;

import java.security.Principal;

import javax.el.ELContext;
import javax.el.ExpressionFactory;
import javax.el.MethodExpression;
import javax.el.ValueExpression;

import javax.faces.application.FacesMessage;
import javax.faces.application.ViewHandler;
import javax.faces.component.ContextCallback;
import javax.faces.component.UIComponent;
import javax.faces.component.UIViewRoot;
import javax.faces.context.FacesContext;

import oracle.adf.share.ADFContext;
import oracle.adf.view.rich.component.fragment.UIXRegion;

import org.apache.myfaces.trinidad.context.RequestContext;


/**
 * Provides various utility methods that are handy to
 * have around when working with ADF.
 */
public class ADFUtil {

    /**
     * Utility method for displaying an error message.
     * @param subject The subject of the error message.
     * @param message The detailed error message.
     * @param severity The severity of the message.
     */
    public static void displayMessage(String subject, String message, FacesMessage.Severity severity) {
        FacesMessage errorMessage = new FacesMessage(severity == null ? FacesMessage.SEVERITY_ERROR : severity, subject, message);
        FacesContext.getCurrentInstance().addMessage(null, errorMessage);
        return;
    }

    /**
     * Utility method for displaying an error message. This version provides the error message pop up
     * on a certain UI component that caused the error. Identified by its client component id.
     * @param subject The subject of the error message.
     * @param message The detailed error message.
     * @param clientId The client ID of the component on which the error message should be popped up.
     * @param severity The severity of the message.
     */
    public static void displayMessage(String subject, String message, String clientId, FacesMessage.Severity severity) {
        FacesMessage errorMessage = new FacesMessage(severity == null ? FacesMessage.SEVERITY_ERROR : severity, subject, message);
        FacesContext.getCurrentInstance().addMessage(clientId, errorMessage);
    }

    /**
     * When a bounded task flow manages a transaction (marked as
     * requires-transaction, requires-new-transaction, or requires-
     * existing-transaction), then the task flow must issue any
     * commits or rollbacks that are needed.
     * This is essentially to keep the state of the transaction that
     * the task flow understands in synch with the state of the
     * transaction in the ADFbc layer.
     * Use this method to issue a commit in the middle of a task flow
     * while staying in the task flow.
     */
    public static void saveAndContinue() {
//        Map sessionMap = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
//        BindingContext context = (BindingContext)sessionMap.get(BindingContext.CONTEXT_ID);
//        String currentFrameName = context.getCurrentDataControlFrame();
//        DataControlFrame dcFrame = context.findDataControlFrame(currentFrameName);
//
//        dcFrame.commit();
//        dcFrame.beginTransaction(null);
    }

    /**
     * Programmatic evaluation of EL.
     *
     * @param el EL to evaluate
     * @return Result of the evaluation
     */
    public static Object evaluateEL(String el) {
        FacesContext facesContext = FacesContext.getCurrentInstance();
        ELContext elContext = facesContext.getELContext();
        ExpressionFactory expressionFactory = facesContext.getApplication().getExpressionFactory();
        ValueExpression exp = expressionFactory.createValueExpression(elContext, el, Object.class);
        return exp.getValue(elContext);
    }

    /**
     * Programmatic invocation of a method that an EL evaluates to.
     * The method must not take any parameters.
     *
     * @param el EL of the method to invoke
     * * @return Object that the method returns
     */
    public static Object invokeEL(String el) {
        return invokeEL(el, new Class[0], new Object[0]);
    }

    /**
     * Programmatic invocation of a method that an EL evaluates to.
     *
     * @param el EL of the method to invoke
     * @param paramTypes Array of Class defining the types of the
     * parameters
     * @param params Array of Object defining the values of the
     * parametrs
     * @return Object that the method returns
     */
    public static Object invokeEL(String el, Class[] paramTypes, Object[] params) {
        FacesContext facesContext = FacesContext.getCurrentInstance();
        ELContext elContext = facesContext.getELContext();
        ExpressionFactory expressionFactory = facesContext.getApplication().getExpressionFactory();
        MethodExpression exp = expressionFactory.createMethodExpression(elContext, el, Object.class, paramTypes);
        return exp.invoke(elContext, params);
    }

    /**
     * Sets a value into an EL object. Provides similar
     * functionality to
     * the &lt;af:setActionListener&gt; tag, except the
     * <code>from</code> is
     * not an EL. You can get similar behavior by using the
     * following...<br>
     * <code>setEL(<b>to</b>, evaluateEL(<b>from</b>))</code>
     *
     * @param el EL object to assign a value
     * @param val Value to assign
     */
    public static void setEL(String el, Object val) {
        FacesContext facesContext = FacesContext.getCurrentInstance();
        ELContext elContext = facesContext.getELContext();
        ExpressionFactory expressionFactory = facesContext.getApplication().getExpressionFactory();
        ValueExpression exp = expressionFactory.createValueExpression(elContext, el, Object.class);
        exp.setValue(elContext, val);
    }

    /**
     * This method gets the page path for the page where a UIComponent resides. I've only tested this method under certain circumstances, so use with caution.
     * @param facesContext
     * @param component
     * @return
     */
    public static String getPagePath(FacesContext facesContext, UIComponent component) {
//        boolean facetRef = false;
//        UIComponent currAncestor = component.getParent();
//        while (currAncestor != null) {
//            if (currAncestor instanceof UIXRegion) {
//                // The component being customized belongs to a region.
//                UIXRegion region = (UIXRegion)currAncestor;
//
//                //We need the viewId of the region, use the ContextCallback mechanism to get it
//                RegionPagePathCallback callback = new RegionPagePathCallback(region);
//                String componentClientId = component.getClientId(facesContext);
//                facesContext.getViewRoot().invokeOnComponent(facesContext, componentClientId, callback);
//                return callback.getRegionPhysicalURI();
//            } else if (currAncestor instanceof UIXPageTemplate) {
//                if (!facetRef) {
//                    //If it reaches this loop, The component is part of pageTemplate
//                    // definition document. get the doc and apply the change
//                    return ((UIXPageTemplate)currAncestor).getViewId();
//                } else {
//                    // This is made false to add the id's in the path to the list
//                    // to make sure that we parse the correct path while parsing the
//                    //XML Document in getComponentNode() method
//                    facetRef = false;
//                }
//            } else if (currAncestor instanceof IncludeTag.FacetWrapper) {
//                //If this is reached, the surrounding pageTemplate def doesn't
//                // contain the required component but the component is child of
//                //pageTemplate component so skip the id's found in between(which
//                // are part of pageTemplate def document) so we no more need to parse
//                // the pageTemplate def file.
//                facetRef = true;
//            }
//            currAncestor = currAncestor.getParent();
//        }
        return null;
    }

    public static String getUsername() {
        Principal principal = ADFContext.getCurrent().getSecurityContext().getUserPrincipal();
        String username = principal.getName();
        return username;
    }

//    public static void setUserInfo(Trackable trackable) {
//        String username = getUsername();
//        trackable.setCreatedUser(username);
//        trackable.setLastModifiedUser(username);
//    }
    
    public static void refresh() {
        FacesContext facesContext = FacesContext.getCurrentInstance();
        String refreshpage = facesContext.getViewRoot().getViewId();
        ViewHandler viewHandler = facesContext.getApplication().getViewHandler();
        UIViewRoot viewroot = viewHandler.createView(facesContext, refreshpage);
        viewroot.setViewId(refreshpage);
        facesContext.setViewRoot(viewroot);
    }

    private static class RegionPagePathCallback implements ContextCallback {
        private String regionPhysicalURI;
        private UIXRegion region;

        RegionPagePathCallback(UIXRegion region) {
            this.region = region;
        }

        public void invokeContextCallback(FacesContext facesContext, UIComponent uiComponent) {
            // This call happens between processBeginRegion and processEndRegion, this is a safe
            //  place to get the viewId and subsequently the physicalURI for the document behind the
            //  region. This region is the first one enclosing the supplied uiComponent here.
            String regionViewId = region.getRegionModel().getViewId(facesContext);
            if (regionViewId != null) {
                RequestContext reqContext = RequestContext.getCurrentInstance();
                if (reqContext != null) {
                    // The viewId we get for regions may not be the physicalURI, hence convert it using
                    //  pageResolver. PageResolvers also are scoped within the region's context,
                    //  hence obtain the physical URI right here.
                    regionPhysicalURI = reqContext.getPageResolver().getPhysicalURI(regionViewId);
                }
            }
        }

        private String getRegionPhysicalURI() {
            return regionPhysicalURI;
        }
    }
}
