package view;


public class SharedContext {
    
    SharedContextImpl currentInstance = null;
    
    public SharedContext() {
        super();
    }
    
    public void setCurrentInstance(SharedContextImpl currentInstance) {
        this.currentInstance = currentInstance;
    }

    public SharedContextImpl getCurrentInstance() {
        return currentInstance;
    }
}
