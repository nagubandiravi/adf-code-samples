package entity;

import java.util.ArrayList;
import java.util.List;


public class NetworkService {
    
    private String id;
    
    private String name;
    
    private String descriptor;
    
    private List<EndPoint> endPoints = new ArrayList<EndPoint>();
    
    public NetworkService() {
        super();
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setDescriptor(String descriptor) {
        this.descriptor = descriptor;
    }

    public String getDescriptor() {
        return descriptor;
    }

    public void setEndPoints(List<EndPoint> endPoints) {
        this.endPoints = endPoints;
    }

    public List<EndPoint> getEndPoints() {
        return endPoints;
    }
}
