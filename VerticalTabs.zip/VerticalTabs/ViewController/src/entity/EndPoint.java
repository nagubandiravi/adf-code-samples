package entity;


public class EndPoint {
    
    private String id;
    
    private String name;
    
    private String vlanID;
    
    private String serviceLocation;
    
    public EndPoint() {
        super();
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setVlanID(String vlanID) {
        this.vlanID = vlanID;
    }

    public String getVlanID() {
        return vlanID;
    }

    public void setServiceLocation(String serviceLocation) {
        this.serviceLocation = serviceLocation;
    }

    public String getServiceLocation() {
        return serviceLocation;
    }

}
