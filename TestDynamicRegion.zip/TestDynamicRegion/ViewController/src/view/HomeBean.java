package view;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;

import oracle.adf.controller.TaskFlowId;
import oracle.adf.view.rich.component.rich.data.RichTable;
import oracle.adf.view.rich.component.rich.fragment.RichRegion;
import oracle.adf.view.rich.component.rich.nav.RichCommandToolbarButton;
import oracle.adf.view.rich.context.AdfFacesContext;

import org.apache.myfaces.trinidad.event.SelectionEvent;
import org.apache.myfaces.trinidad.model.CollectionModel;
import org.apache.myfaces.trinidad.model.SortableModel;


public class HomeBean {
    
    private String taskFlowId = "";
    
    private RichRegion regionBinding;
    
    private CollectionModel activityCollectionModel = new SortableModel();
        
    public HomeBean() {
        super();
        init();
    }
    
    public void init() {
        List models = new ArrayList();
        
        ActivityModel groomModel = new ActivityModel();
        groomModel.setName("Groom Connectivity");
        groomModel.setType("Groom");
        models.add(groomModel);
        
        ActivityModel rehomeModel = new ActivityModel();
        rehomeModel.setName("Rehome Connectivity");
        rehomeModel.setType("Rehome");
        models.add(rehomeModel);
        
        activityCollectionModel.setWrappedData(models);
        
    }

    public void selectAction(ActionEvent actionEvent) {
        RichCommandToolbarButton comp = (RichCommandToolbarButton) actionEvent.getSource();
        ADFUtil.setEL("#{pageFlowScope.invokeButton}", "true");
        if ("Groom".equals(comp.getText())) {
            taskFlowId = "/WEB-INF/GroomFlow.xml";
        } else {
            taskFlowId = "/WEB-INF/RehomeFlow.xml";
        }
//        regionBinding.refresh(FacesContext.getCurrentInstance());
        AdfFacesContext.getCurrentInstance().addPartialTarget(regionBinding);
        
    }

    public void setTaskFlowId(String taskFlowId) {
        this.taskFlowId = taskFlowId;
    }

    public String getTaskFlowId() {
        return taskFlowId;
    }

    public TaskFlowId getDynamicTaskFlowId() {
        return TaskFlowId.parse(taskFlowId);
    }

    public void setRegionBinding(RichRegion regionBinding) {
        this.regionBinding = regionBinding;
    }

    public RichRegion getRegionBinding() {
        return regionBinding;
    }

    public void setActivityCollectionModel(CollectionModel activityCollectionModel) {
        this.activityCollectionModel = activityCollectionModel;
    }

    public CollectionModel getActivityCollectionModel() {
        return activityCollectionModel;
    }

    public void selectRow(SelectionEvent selectionEvent) {
        if (selectionEvent.getAddedSet() != null) {
            RichTable table = (RichTable) selectionEvent.getSource();
            Iterator it = selectionEvent.getAddedSet().iterator();
            while (it.hasNext()) {
                Integer key = (Integer) it.next();
                ActivityModel model = (ActivityModel) table.getRowData(key);
                ADFUtil.setEL("#{pageFlowScope.invokeButton}", "true");
                if ("Groom".equals(model.getType())) {
                    taskFlowId = "/WEB-INF/GroomFlow.xml";
                } else {
                    taskFlowId = "/WEB-INF/RehomeFlow.xml";
                }
                RichRegion regionBindingObj = (RichRegion) ADFUtil.evaluateEL("#{backingBeanScope.regionBinding}");
                regionBindingObj.markInitialState();
                regionBindingObj.refresh(FacesContext.getCurrentInstance());
                AdfFacesContext.getCurrentInstance().addPartialTarget(regionBindingObj);
            }
        }
    }
}
