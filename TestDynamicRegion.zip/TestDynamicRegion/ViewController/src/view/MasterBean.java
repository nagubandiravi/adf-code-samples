package view;

public class MasterBean {
    public MasterBean() {
        super();
    }
    
    public String init() {
        return "success";
    }
}
