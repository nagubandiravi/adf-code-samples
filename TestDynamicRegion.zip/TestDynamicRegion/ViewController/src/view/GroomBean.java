package view;

public class GroomBean {
    
    private String displayLabel;
    
    public GroomBean() {
        super();
//        init();
    }
    
    public String init() {
        System.out.println("In Groom Bean init method");
        displayLabel = "Groom Activity";
        return "success";
    }

    public void setDisplayLabel(String displayLabel) {
        this.displayLabel = displayLabel;
    }

    public String getDisplayLabel() {
        return displayLabel;
    }
}
