package view;

public class RehomeBean {
    
    private String displayLabel;
    
    public RehomeBean() {
        super();
//        init();
    }
    
    public String init() {
        System.out.println("This is init method of Rehome Bean");
        displayLabel = "Rehome Activity";
        return "success";
    }

    public void setDisplayLabel(String displayLabel) {
        this.displayLabel = displayLabel;
    }

    public String getDisplayLabel() {
        return displayLabel;
    }
}
