package view;

import javax.faces.event.ActionEvent;

import oracle.adf.view.rich.component.rich.fragment.RichRegion;
import oracle.adf.view.rich.component.rich.nav.RichCommandLink;
import oracle.adf.view.rich.context.AdfFacesContext;

public class TestBean {
    
    private boolean renderRegion;
    
    public TestBean() {
        super();
    }

    public void execute(ActionEvent actionEvent) {
        RichCommandLink link = (RichCommandLink) actionEvent.getSource();
        if ("Groom".equals(link.getText())) {
            renderRegion = true;
            RichRegion regionBinding = (RichRegion) ADFUtil.evaluateEL("#{backingBeanScope.regionBinding}");
            if (null != regionBinding) {
                AdfFacesContext.getCurrentInstance().addPartialTarget(regionBinding);
            }
        }
    }

    public void setRenderRegion(boolean renderRegion) {
        this.renderRegion = renderRegion;
    }

    public boolean isRenderRegion() {
        return renderRegion;
    }
}
