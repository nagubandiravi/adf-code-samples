package view.src;

import java.util.ArrayList;
import java.util.List;

public class TopologyBean {
    
    private DiagramModel model = new DiagramModel();
    
    public TopologyBean() {
        super();
        init();
    }
    
    public void init() {
        List<TopologyNode> nodes = new ArrayList<TopologyNode>();
        List<TopologyLink> links = new ArrayList<TopologyLink>();
        
        nodes.add(new TopologyNode(0,"First Node",-1));
        nodes.add(new TopologyNode(1,"Second Node",-1));
        nodes.add(new TopologyNode(2,"Third Node",2));
        nodes.add(new TopologyNode(3,"Fourth Node",2));
        nodes.add(new TopologyNode(4,"Fifth Node",1)); 

        nodes.add(new TopologyNode(5,"Second Node Child 1",1));
        nodes.add(new TopologyNode(6,"Second Node Child 2",1));
        nodes.add(new TopologyNode(7,"Fourth Node Child 1",3));
        nodes.add(new TopologyNode(8,"Fourth Node Child 2",3));
        nodes.add(new TopologyNode(9,"Fourth Node Child 3",3));
        
        links.add(new TopologyLink(0,1));
        links.add(new TopologyLink(1,2));
        links.add(new TopologyLink(2,3));  
        links.add(new TopologyLink(3,4));  
        links.add(new TopologyLink(4,0));  

        links.add(new TopologyLink(5,1));  
        links.add(new TopologyLink(6,1));        
        links.add(new TopologyLink(7,8));  
        links.add(new TopologyLink(8,9));
        
        model.setNodes(nodes);
        model.setLinks(links);
        
    }

    public void setModel(DiagramModel model) {
        this.model = model;
    }

    public DiagramModel getModel() {
        return model;
    }
}
