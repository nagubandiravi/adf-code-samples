package view.src;

public class TopologyNode {
    
    private int nodeId;
    
    private String nodeLabel;
    
    private int parentNodeId = -1;
    
    public TopologyNode(int id, String label, int parent) {
        nodeId = id;
        nodeLabel = label;
        parentNodeId = parent;
    }

    public void setNodeId(int nodeId) {
        this.nodeId = nodeId;
    }

    public int getNodeId() {
        return nodeId;
    }

    public void setNodeLabel(String nodeLabel) {
        this.nodeLabel = nodeLabel;
    }

    public String getNodeLabel() {
        return nodeLabel;
    }

    public void setParentNodeId(int parentNodeId) {
        this.parentNodeId = parentNodeId;
    }

    public int getParentNodeId() {
        return parentNodeId;
    }
}
