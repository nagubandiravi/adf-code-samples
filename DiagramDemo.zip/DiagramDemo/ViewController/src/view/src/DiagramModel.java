package view.src;

import java.util.List;

public class DiagramModel {
    
    private List<TopologyNode> nodes = null;
    
    private List<TopologyLink> links = null;
    
    public DiagramModel() {

    }

    public void setNodes(List nodes) {
        this.nodes = nodes;
    }

    public List getNodes() {
        return nodes;
    }

    public void setLinks(List links) {
        this.links = links;
    }

    public List getLinks() {
        return links;
    }
}
