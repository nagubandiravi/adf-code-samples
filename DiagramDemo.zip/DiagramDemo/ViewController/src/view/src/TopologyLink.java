package view.src;

public class TopologyLink {
    
    private int sourceNodeId;
      
    private int destinationNodeId;
          
    public TopologyLink(int source, int destination){
        sourceNodeId = source;
        destinationNodeId = destination;
    }

    public void setSourceNodeId(int sourceNodeId) {
        this.sourceNodeId = sourceNodeId;
    }

    public int getSourceNodeId() {
        return sourceNodeId;
    }

    public void setDestinationNodeId(int destinationNodeId) {
        this.destinationNodeId = destinationNodeId;
    }

    public int getDestinationNodeId() {
        return destinationNodeId;
    }
}
