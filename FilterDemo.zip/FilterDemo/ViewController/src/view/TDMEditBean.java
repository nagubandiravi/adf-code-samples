package view;

public class TDMEditBean {
    
    private String locationA;
    
    private String locationZ;
    
    private String rateCode;
    
    private String function;
    
    private String serialNumber;
    
    private String displayInfo = "";
    
    public TDMEditBean() {
        super();
    }

    public void setLocationA(String locationA) {
        this.locationA = locationA;
    }

    public String getLocationA() {
        return locationA;
    }

    public void setLocationZ(String locationZ) {
        this.locationZ = locationZ;
    }

    public String getLocationZ() {
        return locationZ;
    }

    public void setRateCode(String rateCode) {
        this.rateCode = rateCode;
    }

    public String getRateCode() {
        return rateCode;
    }

    public void setFunction(String function) {
        this.function = function;
    }

    public String getFunction() {
        return function;
    }

    public void setSerialNumber(String serialNumber) {
        this.serialNumber = serialNumber;
    }

    public String getSerialNumber() {
        return serialNumber;
    }

    public void setDisplayInfo(String displayInfo) {
        this.displayInfo = displayInfo;
    }

    public String getDisplayInfo() {
        displayInfo = "";
        if (null != locationA && !displayInfo.contains(locationA)) {
            displayInfo = displayInfo.concat(locationA);
            displayInfo = displayInfo.concat(" / ");
        }
        if (null != locationZ && !displayInfo.contains(locationZ)) {
            displayInfo = displayInfo.concat(locationZ);
            displayInfo = displayInfo.concat(" / ");
        }
        if (null != rateCode && !displayInfo.contains(rateCode)) {
            displayInfo = displayInfo.concat(rateCode);
            displayInfo = displayInfo.concat(" / ");
        }
        if (null != function && !displayInfo.contains(function)) {
            displayInfo = displayInfo.concat(function);
            displayInfo = displayInfo.concat(" / ");
        }
        if (null != serialNumber && !displayInfo.contains(serialNumber)) {
            displayInfo = displayInfo.concat(serialNumber);
            displayInfo = displayInfo.concat(" /// ");
        }
        return displayInfo;
    }
}
