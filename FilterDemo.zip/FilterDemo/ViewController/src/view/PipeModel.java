package view;

public class PipeModel {
    
    private String locA;
    
    private String segment;
    
    private String locZ;
    
    private String networkName;
    
    public PipeModel() {
        super();
    }
    
    public PipeModel(String locationA, String segName, String locationZ, String networkName) {
        setLocA(locationA);
        setSegment(segName);
        setLocZ(locationZ);
        setNetworkName(networkName);
    }

    public void setLocA(String locA) {
        this.locA = locA;
    }

    public String getLocA() {
        return locA;
    }

    public void setSegment(String segment) {
        this.segment = segment;
    }

    public String getSegment() {
        return segment;
    }

    public void setLocZ(String locZ) {
        this.locZ = locZ;
    }

    public String getLocZ() {
        return locZ;
    }

    public void setNetworkName(String networkName) {
        this.networkName = networkName;
    }

    public String getNetworkName() {
        return networkName;
    }
}
