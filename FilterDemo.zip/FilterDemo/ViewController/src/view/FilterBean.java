package view;

import java.util.ArrayList;
import java.util.List;

import javax.el.ELContext;
import javax.el.ExpressionFactory;
import javax.el.ValueExpression;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.event.ValueChangeEvent;

import oracle.adf.view.rich.component.rich.data.RichTable;
import oracle.adf.view.rich.context.AdfFacesContext;
import oracle.adf.view.rich.event.DialogEvent;

import org.apache.myfaces.trinidad.event.SelectionEvent;


public class FilterBean {
    
    private List filterCollectionModel;
    
    private List<String> segmentTypes = null;
    
    private boolean transport;
    
    private boolean facility;
    
    private RichTable resultsTable;
    
    private List networkList = null;
    
    private String currentNetwork = "";
    
    private List<PipeModel> pipeModels = new ArrayList<PipeModel>();
    
    public FilterBean() {
        super();
        init();
    }
    
    public void init(){
        networkList = new ArrayList();
        populatePipeModel();
        filterCollectionModel = new ArrayList();
        TestModel modelObj = null;
        for (PipeModel pipeModelObj: pipeModels) {
            modelObj = new TestModel();
            modelObj.setLocA(pipeModelObj.getLocA());
            modelObj.setLocZ(pipeModelObj.getLocZ());
            modelObj.setSegment(pipeModelObj.getSegment());
            
            if (pipeModelObj.getNetworkName() != null && pipeModelObj.getNetworkName() != "") {
                modelObj.setNetworkIcon(true);
                if (!currentNetwork.equals(pipeModelObj.getNetworkName())) {
                    networkList.add(pipeModelObj.getNetworkName());
                    currentNetwork = pipeModelObj.getNetworkName();
                    modelObj.setNetworkName(pipeModelObj.getNetworkName());
                }
            } else {
                currentNetwork = pipeModelObj.getNetworkName();
            }
            filterCollectionModel.add(modelObj);
        }
    }

    public void setFilterCollectionModel(List filterCollectionModel) {
        this.filterCollectionModel = filterCollectionModel;
    }

    public List getFilterCollectionModel() {
        return filterCollectionModel;
    }

    public void segmentSelectionListener(ValueChangeEvent e) {
        List selectedValues = (ArrayList) e.getNewValue();
        segmentTypes = new ArrayList<String>();
        if (null != selectedValues) {
            for (int j=0; j<selectedValues.size(); j++) {
                segmentTypes.add((String)selectedValues.get(j));
            }
        }
    }
    
    public void handleDialog(DialogEvent event) {
      if (event.getOutcome().equals(DialogEvent.Outcome.ok)) {
           FacesContext facesContext = FacesContext.getCurrentInstance();
           ELContext elContext = facesContext.getELContext();
           ExpressionFactory expressionFactory = facesContext.getApplication().getExpressionFactory();
           filterTable();
           this.setSegmentTypes(null);
           ValueExpression exp = expressionFactory.createValueExpression(elContext, "#{pageFlowScope.FilterBean.resultsTable}", Object.class);
           UIComponent comp = (UIComponent) exp.getValue(elContext);
           AdfFacesContext.getCurrentInstance().addPartialTarget(comp);
      }
    }

    public void setSegmentTypes(List<String> segmentTypes) {
        this.segmentTypes = segmentTypes;
    }

    public List<String> getSegmentTypes() {
        return segmentTypes;
    }
    
    public void filterTable() {
        List tempModel = new ArrayList(filterCollectionModel.size());
        if (segmentTypes != null && segmentTypes.size()>0) {
            for (int i=0; i<filterCollectionModel.size(); i++) {
                TestModel obj = (TestModel) filterCollectionModel.get(i);
                if (null != obj) {
                    if (segmentTypes.contains(obj.getSegment()))
                        continue;
                    else 
                        tempModel.add(obj);
                }
            }
            filterCollectionModel.removeAll(tempModel);
        } else if (segmentTypes == null || segmentTypes.size() == 0) {
            init();
        }
    }

    public void setTransport(boolean transport) {
        this.transport = transport;
    }

    public boolean isTransport() {
        FacesContext facesContext = FacesContext.getCurrentInstance();
        ELContext elContext = facesContext.getELContext();
        ExpressionFactory expressionFactory = facesContext.getApplication().getExpressionFactory();
        ValueExpression exp = expressionFactory.createValueExpression(elContext, "#{row}", Object.class);
        TestModel comp = (TestModel) exp.getValue(elContext);
        if (null != comp) {
            if (comp.getSegment().contains("Transport")) {
                return true;
            }
        }
        return false;
    }

    public void selectAction(SelectionEvent selectionEvent) {
        for (Object facesRowKey : resultsTable.getSelectedRowKeys()) {
            resultsTable.setRowKey(facesRowKey);
            int i = Integer.valueOf(facesRowKey.toString());
            TestModel modelObj = (TestModel) resultsTable.getRowData(i);
            if (null != modelObj && modelObj.getSegment().contains("Transport")) {
                this.setFacility(true);
                i = i-1;
                resultsTable.getSelectedRowKeys().add(Integer.valueOf(i));
                int j = Integer.valueOf(facesRowKey.toString());
                j = j+1;
                resultsTable.getSelectedRowKeys().add(Integer.valueOf(j));
            } else {
                this.setFacility(false);
            }
        }
        FacesContext facesContext = FacesContext.getCurrentInstance();
        ELContext elContext = facesContext.getELContext();
        ExpressionFactory expressionFactory = facesContext.getApplication().getExpressionFactory();
        ValueExpression exp = expressionFactory.createValueExpression(elContext, "#{pageFlowScope.FilterBean.resultsTable}", Object.class);
        UIComponent comp = (UIComponent) exp.getValue(elContext);
        AdfFacesContext.getCurrentInstance().addPartialTarget(comp);
    }

    public void setResultsTable(RichTable resultsTable) {
        this.resultsTable = resultsTable;
    }

    public RichTable getResultsTable() {
        return resultsTable;
    }

    public void setFacility(boolean facility) {
        this.facility = facility;
    }

    public boolean isFacility() {
        return facility;
    }

    public void transportSelected(ValueChangeEvent e) {
        System.out.println(e.getNewValue());
    }

    public void populatePipeModel() {
        PipeModel modelObj = null;
        modelObj = new PipeModel("Plano", "Gap", "", "");
        pipeModels.add(modelObj);
        modelObj = new PipeModel("Plano", "Jumper", "Frisco234", "");
        pipeModels.add(modelObj);
        modelObj = new PipeModel("Frisco234", "CrossConnect", "Frisco456", "NW-Texas");
        pipeModels.add(modelObj);
        modelObj = new PipeModel("Frisco456", "Transport-Frisco456/Frisco678/OC48/OC48N/101/1-2-1", "Frisco678", "NW-Texas");
        pipeModels.add(modelObj);
        modelObj = new PipeModel("Frisco678", "CrossConnect", "Frisco789", "NW-Texas");
        pipeModels.add(modelObj);
        modelObj = new PipeModel("Frisco789", "CrossConnect", "Frisco001", "");
        pipeModels.add(modelObj);
        modelObj = new PipeModel("Frisco001", "Transport-Frisco001/Frisco002/OC48/OC48N/101/1-2-1", "Frisco002", "");
        pipeModels.add(modelObj);
        modelObj = new PipeModel("Frisco002", "CrossConnect", "Frisco003", "");
        pipeModels.add(modelObj);
        modelObj = new PipeModel("Frisco003", "CrossConnect", "Frisco004", "NW-Texas");
        pipeModels.add(modelObj);
        modelObj = new PipeModel("Frisco004", "Transport-Frisco004/Frisco005/OC48/OC48N/101/1-2-1", "Frisco005", "NW-Texas");
        pipeModels.add(modelObj);
        modelObj = new PipeModel("Frisco005", "CrossConnect", "Frisco006", "NW-Texas");
        pipeModels.add(modelObj);
        modelObj = new PipeModel("Frisco006", "Jumper", "Frisco", "");
        pipeModels.add(modelObj);
        modelObj = new PipeModel("", "Gap", "Frisco", "");
        pipeModels.add(modelObj);
    }
}
