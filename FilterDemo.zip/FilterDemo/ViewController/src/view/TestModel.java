package view;

public class TestModel {
    
    private String locA;
    
    private String segment;
    
    private String locZ;
    
    private String networkName;
    
    private boolean networkIcon;
    
    public TestModel() {
        super();
    }
    
    public TestModel(String locationA, String segName, String locationZ, String networkName) {
        setLocA(locationA);
        setSegment(segName);
        setLocZ(locationZ);
        setNetworkName(networkName);
    }

    public void setLocA(String locA) {
        this.locA = locA;
    }

    public String getLocA() {
        return locA;
    }

    public void setSegment(String segment) {
        this.segment = segment;
    }

    public String getSegment() {
        return segment;
    }

    public void setLocZ(String locZ) {
        this.locZ = locZ;
    }

    public String getLocZ() {
        return locZ;
    }

    public void setNetworkName(String networkName) {
        this.networkName = networkName;
    }

    public String getNetworkName() {
        return networkName;
    }

    public void setNetworkIcon(boolean networkIcon) {
        this.networkIcon = networkIcon;
    }

    public boolean isNetworkIcon() {
        return networkIcon;
    }
}
